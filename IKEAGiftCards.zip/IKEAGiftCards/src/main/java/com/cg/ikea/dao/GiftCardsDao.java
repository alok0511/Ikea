package com.cg.ikea.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.ikea.beans.GiftCards;

public class GiftCardsDao implements IGiftCardsDao {

	private EntityManagerFactory factory;
	private EntityManager manager;

	public GiftCardsDao() {
		factory = Persistence.createEntityManagerFactory("GiftCards-Service");
		manager = factory.createEntityManager();
	}

	public boolean updateVerificationCode(String cardNumber, String verificationCode) {

		String issuer = cardNumber.substring(0, 6);
		String cardTypeDigit = cardNumber.substring(6, 7);
		String accountNumber = cardNumber.substring(7, 18);
		String digitCheck = cardNumber.substring(18, 19);

		Query query = manager.createQuery("Select c from GiftCards c where c.issuer=" + issuer + " and c.cardTypeDigit="
				+ cardTypeDigit + " and c.accountNumber=" + accountNumber + " and c.checkDigit=" + digitCheck);

		@SuppressWarnings("unchecked")
		List<GiftCards> list = query.getResultList();
		String cardNumberId = list.get(0).getCardNumberId();
		String defaultVerificationCode = list.get(0).getVerificationCode();
		
		if (defaultVerificationCode == null) {
			manager.getTransaction().begin();
			GiftCards findCard = manager.find(GiftCards.class, cardNumberId);
			findCard.setVerificationCode(verificationCode);
			manager.getTransaction().commit();
			return true;
		}
		
		return false;
	}

}
