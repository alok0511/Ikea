package com.cg.ikea.dao;

public interface IGiftCardsDao {

	public boolean updateVerificationCode(String cardNumber, String verificationCode);
}
