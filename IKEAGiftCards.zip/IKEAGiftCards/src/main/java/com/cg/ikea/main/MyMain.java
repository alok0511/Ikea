package com.cg.ikea.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import com.cg.ikea.dao.GiftCardsDao;
import com.cg.ikea.dao.IGiftCardsDao;
import com.cg.ikea.service.GiftCardsService;
import com.cg.ikea.service.IGiftCardsService;

public class MyMain {

	private static IGiftCardsDao giftCardsDao = new GiftCardsDao();
	private static IGiftCardsService giftCardsService = new GiftCardsService(giftCardsDao);

	public static void main(String[] args) {

		BufferedReader reader;

		try {

			reader = new BufferedReader(new FileReader("/Users/alochaur/Downloads/SELP_load.txt"));
			String line = reader.readLine();

			while (line != null) {
				String str[] = line.split(";");
				String cardNumber = str[0];
				String verificationCode = str[1];

				boolean check = giftCardsService.updateVerificationCode(cardNumber, verificationCode);

				if (check == true) {
					System.out.println("Verification Code updated successfully");
				} else {
					System.out.println("Verification Code already updated");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}