package com.cg.ikea.service;

public interface IGiftCardsService {

	public boolean updateVerificationCode(String cardNumber, String verificationCode);

}
