package com.cg.ikea.service;

import com.cg.ikea.dao.IGiftCardsDao;

public class GiftCardsService implements IGiftCardsService {

	private IGiftCardsDao giftCardsDao;

	public GiftCardsService(IGiftCardsDao giftCardsDao) {
		super();
		this.giftCardsDao = giftCardsDao;
	}

	public boolean updateVerificationCode(String cardNumber, String verificationCode) {

		return giftCardsDao.updateVerificationCode(cardNumber, verificationCode);
	}

}
